-----------------------
# README
-----------------------
CarVilla is a one page bootstrap 3 based Car Dealer Automotive website template.


Template Info:
-----------------------
Name: 		CarVilla - Free Bootstrap One Page Car Dealer Automotive website template
Version: 	1.0
Author: 	ThemeSINE
Website: 	https://www.themesine.com/


Changelog:
-----------------------
Version 1.0 13-06-2018
- initial release 


Credits:
-----------------------
- Twitter Bootstrap http://getbootstrap.com
- jQuery http://jquery.org
- Modernizr https://modernizr.com/
- Sticky.js http://stickyjs.com/
- JQuery easing https://github.com/gdsmith/jquery.easing
- Bootsnav http://bootsnav.danurstrap.com/
- Pexels https://www.pexels.com/
- Unsplash https://unsplash.com/

License:
-----------------------
This template is under Free License - https://www.themesine.com/license/